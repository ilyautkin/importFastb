<?php

$_lang['area_importfastb_main'] = 'Основные';

$_lang['setting_importfastb_some_setting'] = 'Какая-то настройка';
$_lang['setting_importfastb_some_setting_desc'] = 'Это описание для какой-то настройки';