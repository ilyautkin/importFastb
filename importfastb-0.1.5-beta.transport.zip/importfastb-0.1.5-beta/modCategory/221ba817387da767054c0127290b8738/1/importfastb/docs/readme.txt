--------------------
importFastb
--------------------
Author: Ilya Utkin <ilyautkin@mail.ru>
--------------------

MODX addon for linking resources through site.

Feel free to suggest ideas/improvements/bugs on GitHub:
https://github.com/ilyautkin/importFastb