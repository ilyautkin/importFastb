<?php

$_lang['importfastb_prop_limit'] = 'Ограничение вывода Ссылок на странице.';
$_lang['importfastb_prop_outputSeparator'] = 'Разделитель вывода строк.';
$_lang['importfastb_prop_sortBy'] = 'Поле сортировки.';
$_lang['importfastb_prop_sortDir'] = 'Направление сортировки.';
$_lang['importfastb_prop_tpl'] = 'Чанк оформления каждого ряда Ссылок.';
$_lang['importfastb_prop_toPlaceholder'] = 'Усли указан этот параметр, то результат будет сохранен в плейсхолдер, вместо прямого вывода на странице.';
