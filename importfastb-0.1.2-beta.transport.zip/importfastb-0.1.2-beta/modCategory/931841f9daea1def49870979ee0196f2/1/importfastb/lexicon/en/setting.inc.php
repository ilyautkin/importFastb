<?php

$_lang['area_importfastb_main'] = 'Main';

$_lang['setting_importfastb_some_setting'] = 'Some setting';
$_lang['setting_importfastb_some_setting_desc'] = 'This is description for some setting';